
export interface ActionSheetOptions {
  title?: string;
  subTitle?: string;
  cssClass?: string;
  buttons?: Array<any>;
  enableBackdropDismiss?: boolean;
}
