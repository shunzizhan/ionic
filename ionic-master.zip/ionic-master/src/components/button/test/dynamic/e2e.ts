
it('should unify buttons', function() {
  element(by.css('.e2eButtonDynamicUnify')).click();
});
