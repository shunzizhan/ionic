export class Test {
  firstItem;
  constructor() { this.doStuff(); }
  otherMethod() {}
  doStuff() {}
}