export { x as y } from './privateModule';

export abstract class AbstractClass {}